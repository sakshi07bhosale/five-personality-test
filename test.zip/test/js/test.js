// const testForm = document.getElementById('test-form');
// const submitTestBtn = document.getElementById('submit-test-btn');
// const resultsContainer = document.getElementById('results-container');
// const userGreeting = document.getElementById('user-greeting');
// const logoutBtn = document.getElementById('logout-btn');

// // Questions from the PDF
// const questions = [
//     { text: "I tend to be very active at parties.", factor: "extraversion", positive: true },
//     { text: "I often feel sad.", factor: "neuroticism", positive: true },
//     { text: "I tend to waste my time.", factor: "conscientiousness", positive: false },
//     { text: "I make others unhappy.", factor: "agreeableness", positive: false },
//     { text: "I appreciate art.", factor: "openness", positive: true },
//     { text: "I am capable of handling social events.", factor: "extraversion", positive: true },
//     { text: "I make plans and act on them as well.", factor: "conscientiousness", positive: true },
//     { text: "I don't appreciate art.", factor: "openness", positive: false },
//     { text: "I stand alone in social functions.", factor: "extraversion", positive: false },
//     { text: "I am satisfied with myself.", factor: "neuroticism", positive: false },
//     { text: "I am careless towards my responsibilities.", factor: "conscientiousness", positive: false },
//     { text: "I support conservative politicians.", factor: "openness", positive: false },
//     { text: "I prefer to get complete information about something.", factor: "conscientiousness", positive: true },
//     { text: "I accept people the way they are.", factor: "agreeableness", positive: true },
//     { text: "I find pleasure in new ideas.", factor: "openness", positive: true },
//     { text: "My mood often keeps changing.", factor: "neuroticism", positive: true },
//     { text: "I am sharp-tongued.", factor: "agreeableness", positive: false },
//     { text: "I know how to charm people.", factor: "extraversion", positive: true },
//     { text: "I am not easy to anger.", factor: "neuroticism", positive: false },
//     { text: "I do not believe in abstract things (like soul, god, mind, etc.)", factor: "openness", positive: false },
//     { text: "I don't want to draw people's attention towards me.", factor: "extraversion", positive: false },
//     { text: "I talk politely to people.", factor: "agreeableness", positive: true },
//     { text: "I am often sad.", factor: "neuroticism", positive: true },
//     { text: "I am always suspicious of people's intentions.", factor: "agreeableness", positive: false },
//     { text: "I enjoy meeting people.", factor: "extraversion", positive: true },
//     { text: "I can have conversations with the elderly.", factor: "openness", positive: true },
//     { text: "I find it difficult to start tasks.", factor: "conscientiousness", positive: false },
//     { text: "I make friends easily.", factor: "extraversion", positive: true },
//     { text: "I don't panic easily.", factor: "neuroticism", positive: false },
//     { text: "I respect other people.", factor: "agreeableness", positive: true },
//     { text: "I am quick to panic.", factor: "neuroticism", positive: true },
//     { text: "I rarely feel sad.", factor: "neuroticism", positive: false },
//     { text: "I have a vivid imagination.", factor: "openness", positive: true },
//     { text: "I execute all my plans.", factor: "conscientiousness", positive: true },
//     { text: "I don't like talking about certain topics.", factor: "extraversion", positive: false },
//     { text: "I am always ready for my work.", factor: "conscientiousness", positive: true },
//     { text: "I end up insulting others.", factor: "agreeableness", positive: false },
//     { text: "I don't like myself.", factor: "neuroticism", positive: true },
//     { text: "I want to vote for moderate politicians.", factor: "openness", positive: false },
//     { text: "My own experiences have been dull.", factor: "extraversion", positive: false },
//     { text: "I am very happy with myself.", factor: "neuroticism", positive: false },
//     { text: "I take revenge from other people.", factor: "agreeableness", positive: false },
//     { text: "I don't enjoy visiting museums.", factor: "openness", positive: false },
//     { text: "I don't talk much.", factor: "extraversion", positive: false },
//     { text: "I do household chores promptly.", factor: "conscientiousness", positive: true },
//     { text: "I don't want to participate in philosophical arguments.", factor: "openness", positive: false },
//     { text: "I want to comfort other people.", factor: "agreeableness", positive: true },
//     { text: "I work hard to achieve success.", factor: "conscientiousness", positive: true },
//     { text: "I don't pay much attention to things.", factor: "conscientiousness", positive: false },
//     { text: "I believe people have good intentions.", factor: "agreeableness", positive: true }
// ];

// function createQuestionElement(question, index) {
//     const questionDiv = document.createElement('div');
//     questionDiv.classList.add('question');

//     const questionText = document.createElement('p');
//     questionText.textContent = ` ${index + 1}. ${question.text}`;
//     questionDiv.appendChild(questionText);

//     const likertScale = ["Strongly Agree", "Agree", "Neutral", "Disagree", "Strongly Disagree"];

//     likertScale.forEach((option, i) => {
//         const input = document.createElement('input');
//         input.type = 'radio';
//         input.id = q${index}-${i};
//         input.name = q${index};
//         input.value = String(5 - i); // Positive scoring: 5, 4, 3, 2, 1

//         const label = document.createElement('label');
//         label.textContent = option;
//         label.setAttribute('for', q${index}-${i});

//         questionDiv.appendChild(input);
//         questionDiv.appendChild(label);
//     });

//     return questionDiv;
// }

// questions.forEach((question, index) => {
//     const questionElement = createQuestionElement(question, index);
//     testForm.appendChild(questionElement);
// });

// // Display user greeting if logged in
// const userFullName = localStorage.getItem('userFullName');
// if (userFullName) {
//     userGreeting.textContent = Welcome, ${userFullName}!;
//     logoutBtn.style.display = 'block';
// }

// submitTestBtn.addEventListener('click', () => {
//     const answers = [];
//     let allAnswered = true;

//     questions.forEach((question, index) => {
//         const selectedOption = document.querySelector(input[name="q${index}"]:checked);
//         if (selectedOption) {
//             answers.push(parseInt(selectedOption.value, 10));
//         } else {
//             allAnswered = false;
//         }
//     });

//     if (!allAnswered) {
//         alert("Please answer all questions.");





const testForm = document.getElementById('test-form');
const submitTestBtn = document.getElementById('submit-test-btn');
const resultsContainer = document.getElementById('results-container');
const userGreeting = document.getElementById('user-greeting');
const logoutBtn = document.getElementById('logout-btn');


// Questions from the PDF
const questions = [
  { text: "I tend to be very active at parties.", factor: "extraversion", positive: true },
  { text: "I often feel sad.", factor: "neuroticism", positive: true },
  { text: "I tend to waste my time.", factor: "conscientiousness", positive: false },
  { text: "I make others unhappy.", factor: "agreeableness", positive: false },
  { text: "I appreciate art.", factor: "openness", positive: true },
  { text: "I am capable of handling social events.", factor: "extraversion", positive: true },
  { text: "I make plans and act on them as well.", factor: "conscientiousness", positive: true },
  { text: "I don't appreciate art.", factor: "openness", positive: false },
  { text: "I stand alone in social functions.", factor: "extraversion", positive: false },
  { text: "I am satisfied with myself.", factor: "neuroticism", positive: false },
  { text: "I am careless towards my responsibilities.", factor: "conscientiousness", positive: false },
  { text: "I support conservative politicians.", factor: "openness", positive: false },
  { text: "I prefer to get complete information about something.", factor: "conscientiousness", positive: true },
  { text: "I accept people the way they are.", factor: "agreeableness", positive: true },
  { text: "I find pleasure in new ideas.", factor: "openness", positive: true },
  { text: "My mood often keeps changing.", factor: "neuroticism", positive: true },
  { text: "I am sharp-tongued.", factor: "agreeableness", positive: false },
  { text: "I know how to charm people.", factor: "extraversion", positive: true },
  { text: "I am not easy to anger.", factor: "neuroticism", positive: false },
  { text: "I do not believe in abstract things (like soul, god, mind, etc.)", factor: "openness", positive: false },
  { text: "I don't want to draw people's attention towards me.", factor: "extraversion", positive: false },
  { text: "I talk politely to people.", factor: "agreeableness", positive: true },
  { text: "I am often sad.", factor: "neuroticism", positive: true },
  { text: "I am always suspicious of people's intentions.", factor: "agreeableness", positive: false },
  { text: "I enjoy meeting people.", factor: "extraversion", positive: true },
  { text: "I can have conversations with the elderly.", factor: "openness", positive: true },
  { text: "I find it difficult to start tasks.", factor: "conscientiousness", positive: false },
  { text: "I make friends easily.", factor: "extraversion", positive: true },
  { text: "I don't panic easily.", factor: "neuroticism", positive: false },
  { text: "I respect other people.", factor: "agreeableness", positive: true },
  { text: "I am quick to panic.", factor: "neuroticism", positive: true },
  { text: "I rarely feel sad.", factor: "neuroticism", positive: false },
  { text: "I have a vivid imagination.", factor: "openness", positive: true },
  { text: "I execute all my plans.", factor: "conscientiousness", positive: true },
  { text: "I don't like talking about certain topics.", factor: "extraversion", positive: false },
  { text: "I am always ready for my work.", factor: "conscientiousness", positive: true },
  { text: "I end up insulting others.", factor: "agreeableness", positive: false },
  { text: "I don't like myself.", factor: "neuroticism", positive: true },
  { text: "I want to vote for moderate politicians.", factor: "openness", positive: false },
  { text: "My own experiences have been dull.", factor: "extraversion", positive: false },
  { text: "I am very happy with myself.", factor: "neuroticism", positive: false },
  { text: "I take revenge from other people.", factor: "agreeableness", positive: false },
  { text: "I don't enjoy visiting museums.", factor: "openness", positive: false },
  { text: "I don't talk much.", factor: "extraversion", positive: false },
  { text: "I do household chores promptly.", factor: "conscientiousness", positive: true },
  { text: "I don't want to participate in philosophical arguments.", factor: "openness", positive: false },
  { text: "I want to comfort other people.", factor: "agreeableness", positive: true },
  { text: "I work hard to achieve success.", factor: "conscientiousness", positive: true },
  { text: "I don't pay much attention to things.", factor: "conscientiousness", positive: false },
  { text: "I believe people have good intentions.", factor: "agreeableness", positive: true }
];


function createQuestionElement(question, index) {
  const questionDiv = document.createElement('div');
  questionDiv.classList.add('question');


  const questionText = document.createElement('p');
  questionText.textContent = ` ${index + 1}. ${question.text}`;
  questionDiv.appendChild(questionText);


  const likertScale = ["Strongly Agree", "Agree", "Neutral", "Disagree", "Strongly Disagree"];


  likertScale.forEach((option, i) => {
    const input = document.createElement('input');
    input.type = 'radio';
    input.id = q${ index } -${ i };
    input.name = q${ index };
    input.value = String(5 - i); // Positive scoring: 5, 4, 3, 2, 1


    const label = document.createElement('label');
    label.textContent = option;
    label.setAttribute('for', q${ index } - ${ i });


    questionDiv.appendChild(input);
    questionDiv.appendChild(label);
  });


  return questionDiv;
}


questions.forEach((question, index) => {
  const questionElement = createQuestionElement(question, index);
  testForm.appendChild(questionElement);
});


// Display user greeting if logged in
const userFullName = localStorage.getItem('userFullName');
if (userFullName) {
  userGreeting.textContent = Welcome, ${ userFullName } !;
  logoutBtn.style.display = 'block';
}


submitTestBtn.addEventListener('click', () => {
  const answers = [];
  let allAnswered = true;


  questions.forEach((question, index) => {
    const selectedOption = document.querySelector(input[name = "q${index}"]: checked);
    if (selectedOption) {
      answers.push(parseInt(selectedOption.value, 10));
    } else {
      allAnswered = false;
    }
  });


  if (!allAnswered) {
    alert("Please answer all questions.");
    return;
  }


  const results = calculateResults(answers);
  displayResults(results);
});


function calculateResults(answers) {
  const results = {
    extraversion: 0,
    agreeableness: 0,
    conscientiousness: 0,
    neuroticism: 0,
    openness: 0
  };


  questions.forEach((question, index) => {
    let score = answers[index];
    if (!question.positive) {
      score = 6 - score; // Reverse scoring for negatively keyed items
    }
    results[question.factor] += score;
  });


  return results;
}


function displayResults(results) {
  let resultsHTML = '<h2>Your Big Five Personality Scores</h2>';
  for (const factor in results) {
    let interpretation = "";
    if (results[factor] <= 30) {
      interpretation = "(Below Average)";
    } else {
      interpretation = "(Average or Above)";
    }
    resultsHTML += <p><b>${factor.charAt(0).toUpperCase() + factor.slice(1)}:</b> ${results[factor]} ${interpretation}</p>;
  }
  resultsContainer.innerHTML = resultsHTML;
  resultsContainer.style.display = 'block';
  testForm.style.display = 'none'; // Hide the form after submission


  // Store results in local storage
  localStorage.setItem('bigFiveResults', JSON.stringify(results));
}


logoutBtn.addEventListener('click', () => {
  localStorage.removeItem('userEmail');
  localStorage.removeItem('userFullName');
  localStorage.removeItem('userPassword');
  window.location.href = 'index.html';
});
